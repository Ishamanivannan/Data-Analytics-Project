# 📊 Sales Analytics Dashboard

## 📌 Project Overview

This project is an Excel-based Sales Analytics Dashboard created to analyze sales performance and generate meaningful business insights.

## 🛠️ Tool Used

- Microsoft Excel

## 📈 Dashboard Features

- Total Revenue
- Total Units Sold
- Average Revenue
- Total Transactions
- Product-wise analysis
- Category-wise analysis
- Region-wise analysis
- Sales trend visualization
- Interactive filters and slicers
- Data visualization

## 🎯 Objective

The objective of this project is to analyze sales data and present important sales information through an interactive Excel dashboard.

## 📸 Dashboard Preview

![Sales Analytics Dashboard](images/sales-dashboard.png)

## 📥 Download Dashboard

[📊 Open / Download Sales Analytics Dashboard (Excel)](Sales_Analytics_Dashboard.xlsx)

## 💡 Skills Demonstrated

- Data Analysis
- Microsoft Excel
- Dashboard Creation
- Data Visualization
- Pivot Tables / Charts
- Interactive Slicers
- Business Insights

## 📂 Project Files

- `Sales_Analytics_Dashboard.xlsx` – Excel dashboard
- `images/sales-dashboard.png` – Dashboard preview
- `README.md` – Project documentation
